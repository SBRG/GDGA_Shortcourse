# Growth Coupling Suite
Framework for computing and analyzing strain designs that couple a target reaction to growth

## Installation
The Growth Coupling Suite has been tested in Python 3.8 and 3.9
1. Install COBRApy (run `pip install cobra`) ([documentation](https://cobrapy.readthedocs.io/en/latest/))
2. Install the Gurobi solver software under an (academic) license (https://www.gurobi.com/)
3. Install gurobipy (run `pip install -i https://pypi.gurobi.com gurobipy`) ([documentation](https://www.gurobi.com/documentation/9.1/quickstart_mac/cs_using_pip_to_install_gr.html))
4. Clone/fork/download this repository
5. Browse to the main directory of the repo and run `python setup.py install` or `python setup.py develop` (for code development purposes)

## Use
Refer to or run the `example\conduct_gcOpt_optimization.py` for an example of how to set up and use the Growth Coupling Suite.

__Note:__
The first computation with a new model can be quite time consuming due to the curation of the heterologous reaction database. The database will automatically be saved for later applications of that model.  
