# Methods for reducing model size and target reaction space

import cobra
import pandas as pd

# from growth_coupling_suite.model_processing import model_processing




def blocked_reactions(model, reaction_list=[], remove_blocked_reactions=False):
    # identify blocked reactions via FVA and remove/disable
    
    # with model:
        # populate list of reactions to be checked
    if len(reaction_list) > 0:
        rxn_list = reaction_list
        # rxn_list = [model.reactions.get_by_any(rxn) for rxn in reaction_list]
    else:
        rxn_list = model.reactions
    
    # # conduct flux variability analysis    
    # sol_fva = cobra.flux_analysis.variability.flux_variability_analysis(
    #                 model,
    #                 reaction_list=rxn_list,
    #                 fraction_of_optimum=0,
    #                 processes=1)
    
    # manual fva (stumbled over problems with copied model)
    fva_res = []
    rxn_id = []
    for rxn in rxn_list:
        with model:
            rxn_id.append(rxn.id)
            model.objective = rxn.id
            # maximize
            model.objective_direction = "max"
            sol_max = model.slim_optimize()
            # minimize
            model.objective_direction = "min"
            sol_min = model.slim_optimize()
            # concatenate
            fva_res.append([sol_min, sol_max])
            
    # create frame
    sol_fva = pd.DataFrame(fva_res, index=rxn_id, columns=["minimum", "maximum"])
        
    # analyze results
    blocked_reactions = []
    for rxn in sol_fva.index:
        if sol_fva.loc[rxn, "minimum"]==0 and sol_fva.loc[rxn, "maximum"]==0:  
            blocked_reactions.append(rxn)
            
    # remove blocked reactions
    if remove_blocked_reactions:
        model.remove_reactions(blocked_reactions, remove_orphans=False)
    
    
    
    return model, blocked_reactions


def essential_reactions(model, reaction_list=[], objective_cutoff=1e-03):
    # populate reaction list to be analyzed
    
    if not reaction_list:
        reaction_list = [rxn for rxn in model.reactions]
    else:
        reaction_list_valid = []
        for rxn in reaction_list:
            try:
                reaction_list_valid.append(model.reactions.get_by_any(rxn)[0])
            except:
                continue
        reaction_list = reaction_list_valid
    
    # identify essential reactions
    essential_reactions = []
    for rxn in reaction_list:
        with model:
            rxn = model.reactions.get_by_id(rxn.id)
            # knockout reaction
            rxn.bounds = (0, 0)
            # print(model.reactions.get_by_id(rxn_id).upper_bound)
            # optimize model
            if model.slim_optimize()  < objective_cutoff:
                # essential reaction
                essential_reactions.append(rxn.id)
                
    return essential_reactions
        



def flux_coupling_analysis(model_in, reaction_list=[], remove_blocked_reactions=False):
    # investigate coupling between fluxes (cf. Burgard et al. 2004)
    # optionally remove blocked reactions
    
    # parameter
    significant_flux = 1e-05
    
    model = model_in.copy()
    
    # relax maintenance reactions
    model.reactions.ATPM.lower_bound = 0
    
    
    
    # make model irreversible
    # model = model_processing.make_model_irreversible(model, copy_model=False)

   
    
    # populate reaction list to be analyzed
    if not reaction_list:
        reaction_list = [rxn for rxn in model.reactions]
    else:
        reaction_list_valid = []
        for rxn in reaction_list:
            try:
                reaction_list_valid.append(model.reactions.get_by_any(rxn))
            except:
                continue
        reaction_list = reaction_list_valid
      
    # return reaction_list, model
    # return reaction_list, model
    # conduct a flux variability analysis
    sol_fva = cobra.flux_analysis.variability.flux_variability_analysis(
                    model,
                    reaction_list=reaction_list,
                    fraction_of_optimum=0,
                    processes=1)

    # flux coupling algorithm
    already_coupled = []
    reaction_couples = []
    for rxn in reaction_list:
        print(rxn.id)
        # check if reaction is already in a couplig cluster
        if rxn.id in already_coupled:
            continue
        # fix flux of reaction to unit value
        lb_ub = [rxn.lower_bound, rxn.upper_bound] # save bounds to restore later
        if sol_fva.loc[rxn.id, "maximum"] > 1:
            fix_flux_rate = 1
        elif sol_fva.loc[rxn.id, "minimum"] < -1:
            fix_flux_rate = -1
        else:
            # flux range too small for analysis
            continue               
        rxn.lower_bound = fix_flux_rate
        rxn.upper_bound = fix_flux_rate
        
        # # disable reverse flux
        # is_reverse = False
        # if "_forward" in rxn.id:
        #     rxn_r = model.reactions.get_by_id(rxn.id[:rxn.id.index("_forward")] + "_reverse")
        #     rxn_r_ub = rxn_r.upper_bound
        #     rxn_r.upper_bound = 0
        #     is_reverse = True
        # elif "_reverse" in rxn.id:
        #     rxn_r = model.reactions.get_by_id(rxn.id[:rxn.id.index("_reverse")] + "_forward")
        #     rxn_r_ub = rxn_r.upper_bound
        #     rxn_r.upper_bound = 0
        #     is_reverse = True
            
        # optimize all other fluxes
        cluster = [rxn.id]
        for rxn_couple in reaction_list:
            if rxn_couple.id in already_coupled or rxn_couple.id == rxn.id:
                continue
            # optimize model
            model.objective = rxn_couple.id
            model.objective_direction = "min"
            sol_min = model.slim_optimize()
            model.objective_direction = "max"
            sol_max = model.slim_optimize()
            # evaluate coupling
            if sol_min == sol_max:
                # fully coupled
                cluster.append(rxn_couple.id)
                already_coupled.append(rxn_couple.id)
                print("\t" + rxn_couple.id + " (fully coupled)")
            if sol_min*sol_max > 0 \
                and abs(sol_min-sol_fva.loc[rxn.id, "minimum"]) > significant_flux \
                and abs(sol_fva.loc[rxn.id, "maximum"]-sol_max) > significant_flux:
                # partially coupling
                cluster.append(rxn_couple.id)
                already_coupled.append(rxn_couple.id)
                print("\t" + rxn_couple.id)
            elif sol_min > significant_flux \
                or sol_max < (sol_fva.loc[rxn.id, "maximum"]-significant_flux):
                # directionally coupled
                # for do not considerred as coupled as coupling in one direction does not neccessarily imply coupling in the other direction
                pass
            else:
                # uncoupled
                pass
         
        # save coupling cluster
        if len(cluster) > 1:
            reaction_couples.append(cluster)
           
        already_coupled.append(rxn.id)
        
        # relax boundaries of reactions again
        rxn.lower_bound = lb_ub[0]
        rxn.upper_bound = lb_ub[1]
        # if is_reverse:
        #     rxn_r.upper_bound = rxn_r_ub
        
            
    # optionally remove blocked reaction
    if remove_blocked_reactions:
        blocked_reactions = []
        for rxn in sol_fva.index:
            if sol_fva.loc[rxn, "minimum"]==0 and sol_fva.loc[rxn, "maximum"]==0:  
                blocked_reactions.append(rxn)
        model.remove_reactions(blocked_reactions, remove_orphans=False)
        # remove blocked reactions from reaction list    
        for couple in reaction_couples:
            intersect = list(set(couple).intersection(set(blocked_reactions)))
            for rxn in intersect: couple.remove(rxn)
        
            
    return reaction_couples
                
            
        
    